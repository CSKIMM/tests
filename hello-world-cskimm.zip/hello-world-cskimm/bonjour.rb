#bonjour

require 'sinatra'

get '/' do
  "Hello from Toronto!"
end